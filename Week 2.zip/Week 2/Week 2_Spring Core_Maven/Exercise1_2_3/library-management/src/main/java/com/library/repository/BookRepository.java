package com.library.repository;

public class BookRepository {
    public void saveBook() {
        // Logic to save a book
        System.out.println("Saving book...");
    }
}
