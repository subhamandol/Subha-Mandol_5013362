package com.library;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    public void doRepositoryWork() {
        // Add repository logic here
        System.out.println("Repository work executed");
    }
}

